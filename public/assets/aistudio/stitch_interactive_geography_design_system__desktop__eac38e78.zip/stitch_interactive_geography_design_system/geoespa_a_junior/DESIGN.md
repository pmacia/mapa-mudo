---
name: GeoEspaña Junior
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#855300'
  on-secondary: '#ffffff'
  secondary-container: '#fea619'
  on-secondary-container: '#684000'
  tertiary: '#632ecd'
  on-tertiary: '#ffffff'
  tertiary-container: '#7d4ce7'
  on-tertiary-container: '#f6edff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#e9ddff'
  tertiary-fixed-dim: '#d0bcff'
  on-tertiary-fixed: '#23005c'
  on-tertiary-fixed-variant: '#5516be'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
  success-emerald: '#10B981'
  adventure-orange: '#F97316'
  danger-rose: '#EF4444'
  map-water-light: '#E0F2FE'
  map-land-light: '#FEF3C7'
  category-rivers: '#0284C7'
  category-mountains: '#D97706'
  category-peaks: '#DC2626'
  category-coasts: '#0D9488'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '800'
    lineHeight: 36px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '800'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '800'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-md-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '800'
    lineHeight: 24px
    letterSpacing: -0.01em
  title-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-base:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: '0'
  body-bold:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: '0'
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: '0'
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '800'
    lineHeight: 14px
    letterSpacing: 0.06em
  stat-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '800'
    lineHeight: 32px
    letterSpacing: -0.02em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 0.75rem
  margin-tablet: 1rem
  margin-desktop: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system delivers a vibrant, energetic, and tactile gamified educational environment tailored specifically for 1st-year secondary school students (1º de la ESO, ages 11–13). Drawing core inspiration from modern gamified learning platforms and arcade interfaces, the aesthetic balances cartographic clarity with triumphant feedback loops, streak mechanics, and playful 3D-styled physical interactions.

### Personality & Tone
- **Optimistic & Energetic**: Eliminates dry textbook friction through vibrant jewel tones, animated reward indicators, and celebratory micro-interactions.
- **Friendly & Accessible**: Approachable geometry, generous hit zones, and welcoming rounded surfaces lower cognitive barriers for early adolescents.
- **Tactile & Responsive**: Interactive elements feel physically pressable, providing immediate visual affordance, responsive compression (`active:scale-95`), and tactile depth.
- **Focused & Structured**: Cartographic precision remains paramount; UI panels frame rather than obscure the geographic canvas.

### Visual Movement
The design movement is **Tactile Gamified Ed-Tech**—a synthesis of rounded flat styling, subtle extruded 3D bevels, airy surface cards, and high-visibility status chips.

## Colors

The palette anchors on electric atlas blue and balances high-energy gamification accents against clean slate surfaces to ensure map features remain vivid and legible.

### Core Roles
- **Primary (`#2563EB`)**: Anchor color representing physical water, navigation paths, primary CTAs, active quiz modes, and focus states.
- **Secondary (`#F59E0B`)**: Trophy gold applied to XP achievements, score counters, streak milestones, and hint badges.
- **Tertiary (`#8B5CF6`)**: Relieved purple for challenge tiers, difficulty tags, rank progression, and discovery modes.
- **Neutral (`#64748B`)**: Structural slate providing balance through borders, card outlines, muted metadata, and secondary icons.

### Specialized Gamification & Cartographic Tokens
- **`success-emerald` (`#10B981`)**: Answer validation, level mastery, and streak continuation.
- **`adventure-orange` (`#F97316`)**: Time pressure countdowns in 60-second Blitz, active combo streaks, and warnings.
- **`danger-rose` (`#EF4444`)**: Mistake feedback, heart/life depletion, and critical alerts.
- **`map-water-light` (`#E0F2FE`) & `map-land-light` (`#FEF3C7`)**: Foundational geographic canvas surfaces for vector relief and ocean boundaries.
- **Category Colors**: Dedicated thematic pigments (`category-rivers`, `category-mountains`, `category-peaks`, `category-coasts`) for instantaneous cognitive filtering during interactive map exploration.

## Typography

The typographic hierarchy pairs **Plus Jakarta Sans** for prominent headings, gamified badge stats, and micro-labels with **Inter** for descriptions, hints, and instructional text.

### Architectural Rules
- **Display and Title Levels**: Use bold weights (700 and 800) with slight negative tracking to give headlines an upbeat, confident arcade feel.
- **Body Text**: Driven by Inter at medium and bold weights for rapid comprehension by 11–13 year-olds across mobile and desktop displays.
- **Labels & Badges (`label-caps`)**: Always uppercase with widened letter spacing (`0.06em`) to ensure quick legibility on small pill badges.
- **Stat Counters (`stat-lg`)**: Employ tabular numbers where possible to avoid horizontal jitter during rapid countdown timers and score increments.

## Layout & Spacing

The layout model is based on a responsive fluid grid system designed around a prominent visual map viewport and supporting gamification controls.

### Grid & Viewport Organization
- **Mobile (< 768px)**: 4-column layout with `margin: 0.75rem` and `gutter: 1rem`. Content flows in a single vertical stack where the map occupies the primary screen real estate, supplemented by sticky thumb-level floating navigation and pull-up sheets.
- **Tablet (768px - 1023px)**: 8-column layout with `margin-tablet: 1rem`. Map and quiz prompts adjust dynamically to allow touch interaction without overlapping feature labels.
- **Desktop (>= 1024px)**: 12-column layout with `margin-desktop: 1.5rem` and `gutter-desktop: 1.5rem` capped at `1280px` maximum container width. 8 columns are assigned to the interactive SVG map, while 4 columns form a dedicated right-hand quiz dock.

### Touch Target Standard
All interactive elements strictly maintain a minimum tap target dimension of `48px x 48px` on touch screens.

## Elevation & Depth

Visual depth is achieved through tactile micro-relief rather than diffuse photorealistic shadows. Elements use crisp foundation outlines and extruded lower-edge depth to emulate tactile physical arcade buttons.

### Elevation Hierarchy
- **Level 0 (Canvas Ground)**: `#F8FAFC` base page background and cartographic water planes.
- **Level 1 (Surface Cards & Options)**: White `#FFFFFF` floating containers surrounded by a clean 1.5px border (`#E2E8F0`) with a subtle offset drop: `box-shadow: 0 3px 0 #E2E8F0`.
- **Level 2 (Tactile 3D Buttons & Active Pills)**: Raised interactive buttons featuring an extrusion baseline of 3px to 4px using a deeper shade of the surface color (e.g., `#1D4ED8` underneath `#2563EB`). On click or tap, the component translates down by 2px (`translate-y-0.5`) with reduced shadow, reinforcing a physical keystroke.
- **Level 3 (Modals & Bottom Drawers)**: High-priority dialogue boxes and celebration drawers elevated with `box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.15)` paired with a soft background scrim (`rgba(15, 23, 42, 0.4)`).

## Shapes

The interface embraces a pill-shaped and deeply rounded visual language (`roundedness: 3`), radiating warmth, safety, and modern gaming ergonomics.

### Implementation Guidelines
- **Buttons, Mode Switchers, & Interactive Badges**: Formed as full pills (`border-radius: 9999px`) or hyper-rounded blocks (`rounded-2xl` / 1rem to 1.5rem), providing comfortable thumb targets without sharp vertices.
- **Content Cards & Challenge Panels**: Built using `rounded-2xl` (1rem to 1.5rem) and `rounded-3xl` (2rem) on primary modal wrappers.
- **Drawers & Bottom Sheets**: Configured with sweeping top corner radii (`rounded-t-3xl` / 2rem) to distinguish contextual overlays from the underlying map canvas.

## Components

### Buttons
- **Primary Game Action**: Pill or `rounded-2xl` structure with electric blue `#2563EB` fill, white bold label, and a 3px darker under-edge (`#1D4ED8`). Hover deepens the tint; active press translates 2px downward.
- **Trophy / Milestone Action**: Same tactile structure using trophy gold `#F59E0B` and an under-edge of `#D97706`.
- **Ghost & Secondary Controls**: Crisp white background, `#E2E8F0` border, `box-shadow: 0 2px 0 #CBD5E1`, and dark slate typography.

### Chips & Interactive Pills
- **Game Mode Switcher**: Segmented horizontal pill dock containing compact items for *Ubicar*, *Quiz*, *Contrarreloj*, and *Explorar*. Active state takes an energetic background with white text; inactive items remain neutral slate.
- **Category Tags**: Color-coded pill markers using dedicated thematic accents with low-opacity fills and solid high-contrast borders (e.g., `#E0F2FE` background with `#0284C7` border and text for Rivers).

### Lists & Selection Cards
- **Multiple-Choice Quiz Answers**: Full-width rounded cards (`rounded-xl` to `rounded-2xl`) featuring 12px to 16px internal padding, clear letter indicator badges (A, B, C, D), and neutral slate outlines.
  - *Correct State*: Shifts instantly to emerald green (`#10B981`) surface and border with bold white text.
  - *Incorrect State*: Shifts to crimson rose (`#EF4444`) with a rapid horizontal shake cue.

### Checkboxes & Radios
- Rendered as bold circular buttons with a 2px outer ring. Checked states animate an energetic check icon scaled up from center with an emerald or blue fill.

### Input Fields
- Search and text inputs utilize pill silhouettes (`rounded-full`), comfortable `48px` height, `#FFFFFF` fill, 1.5px slate borders, and inset search icons with clear tap triggers. Focus triggers an electric blue outer ring without visual layout shift.

### Cards & Overlay Panels
- **Challenge Dock**: Floating companion container with backdrop blur, rounded corners (`rounded-2xl`), and a structured header holding game telemetry.
- **Streak & XP Counter**: Compact pill container holding the streak flame (`#F97316`) or XP gem (`#F59E0B`), tabular score numbers, and animated bounce transitions on value change.
- **Life Bar / Hearts**: Trio of vibrant red hearts transitioning to muted gray outlines upon incorrect choices.
- **Progress Track**: Horizontal track with discrete circular pips indicating completed questions, current active challenge, and unreached milestones.